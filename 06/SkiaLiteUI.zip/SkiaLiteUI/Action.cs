﻿using System;
using System.Collections.Generic;

namespace SkiaLiteUI;

//public interface Action
//{
//    void Act(float deltaTime);
//}
