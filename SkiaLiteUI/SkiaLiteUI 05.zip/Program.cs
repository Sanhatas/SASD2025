﻿namespace SkiaLiteUI
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello, World!");
            new WinTest().Run();
        }
    }
}
